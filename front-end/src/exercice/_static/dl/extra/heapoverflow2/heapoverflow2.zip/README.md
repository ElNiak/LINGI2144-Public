# Heap-Based Overflow - Function pointers

## Introduction

In this exercise we will exploit a heap-based vulnerabilities to execute a function that we should not be allowed to.

The `exploit_func` program takes password as a parameter and displays *Auth : success* if it is correct, *Auth : failed* otherwise. For the sake of simplicity we always deny every password but assume that there is one.

If we take a look at the `exploit_func.c` file we can see two structures as well as two functions, one of which is supposedly called on authentication success. This will be our aim for this lab.

## Exercices

### Finding vulnerable code

❓ Can you spot which line of code is vulnerable to a heap-based overflow ?

Try to see how much bytes your can put as parameter before crashing the program.

### Locate the heap in memory

❓ Using gdb find the allocation instructions for the two structures and how much bytes are allocated.

❓ Using gdb can you find a way to locate the address of the heap?

💡 **HINT** You can put a breakpoint somewhere in the program and see the state of the registers as well as other usefull information regarding the stack and the heap. Once you find the heap you can take a look at its content easily.

### Locate the two structures

❓ Using gdb can you locate the address of the two buffers?

💡 **HINT** Recall that the second structure is a pointer to a function so maybe you should look at the addresses of both functions to see any resemblance.. 

❓ Find what's the distance between the two structures in memory.

### Crashing the program

Now that you have found the distance between the two structures you should be able to crash the program with control. 
To see if you calculated your offest correctly you can open gdb and run it with a string with the length of your offset and some distinguishable bytes.
You should be able to a segmentation fault with the four dinstinguishable bytes as the address.
If this is correct you just need to replace the four bytes by a useful address, `allowed` for example.

❓ Find the address of the `allowed` function.

❓ Execute the `allowed` function using your exploit.
