#include "stdio.h"
#include "stdlib.h"
#include "string.h"

void main(){
  char *a; 
  printf("%s",a);
}

