#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>

int main(int argc, char* argv[]){
  int userid, fd; // File descriptor
  char * buffer, *datafile;
  
  buffer = (char *) malloc(100);
  if (buffer == NULL)
    return -1;

  datafile = (char *) malloc(20);
  if (datafile == NULL)
    return -1;
  strcpy(datafile, "/var/notes");
  
  if (argc < 2){
    printf("Usage : ./note-taker \'Some very interesting message\'\n");
    return-1;
  }
  strcpy(buffer, argv[1]);

  printf("[DEBUG] buffer @ %p: \'%s\'\n", buffer, buffer);
  printf("[DEBUG] datafile @ %p: \'%s\'\n", datafile, datafile);

  fd = open(datafile,O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
  if (fd == -1)
    return -1;
  write(fd, "\n", 1);
  
  if (write(fd, buffer, strlen(buffer)) == -1)
    return -1;
  write(fd, "\n", 1);

  if (close(fd) == -1)
    return -1;

  printf("Note has been saved. \n");
  free(buffer);
  free(datafile);
}
