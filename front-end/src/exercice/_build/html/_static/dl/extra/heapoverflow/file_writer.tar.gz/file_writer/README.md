# Heap-Based Overflow - Abusing the file system

‼️ Before you start this exercise I **STRONGLY** suggest that you backup any important file on your VM ‼️

```console
$ cp /etc/passwd /tmp/passwd.bkup
```

## Introduction

In this exercice, we will see how we can exploit the heap to create a new user with root access.

The program we will be exploiting is a simple note taker that will write the user input into a file located at `/var/notes`. 
This simple piece of code is poorly written and is vulnerable to a heap-based overflow.

We can try this program with some simple input like :

```console
$ ./note_taker "Some boring text"
[DEBUG] buffer @ 0x804d1a0: 'Some boring text'
[DEBUG] datafile @ 0x804d210: '/var/notes'
Note has been saved. 
$ sudo cat /var/notes

Some boring text
$
```

## Exercises
### Finding vulnerable code
❓Can you spot which line of code is vulnerable to a heap-based overflow ?

💡 **HINT** Don't forget how the memory is based and the difference between the stack and the heap.

### Locate the heap in memory
It is often usefull to take a look at the heap's memory to debug. In this case we want to see where in memory the *datafile* and *buffer* variables are located. (We assume that we don't print any DEBUG information)

❓ Using *gdb* can you find a way to locate the address of the heap?

💡 **HINT** You can put a breakpoint somewhere in the program and see the state of the registers as well as other usefull information regarding the stack and the heap. Once you find the heap you can take a look at its content easily.


### Locate the two buffers
❓ Using *gdb* can you locate the address of the two buffers?

💡 **HINT** You may want to use some distinguishable input ("AAAABBBBCCCC", "ABCDEFGH", ...) that you can spot easily while looking at the memory.

Once you have found the two buffers in memory you can calculate the length needed to overflow the buffer into the datafile.

❓Using *gdb* find the number of bytes needed to overflow the second buffer.

❗**WARNING** When using *gdb* to compute values using addresses, it might sometime display the result in hexadecimal value.
```console
(gdb) p 0xdeadbeef - 0xdeadbeaf
$1 = 0x40
(gdb) p/d 0xdeadbeef - 0xdeadbeaf
$2 = 64
```

### Predicting the file name
Now that you now how much bytes you need for the padding you should be able to write to a file of your choice.

❓ Try writing to the file `/var/test`.

💡 **HINT** You can use perl or python to generate long strings.

You can look at the result using `sudo cat /var/test`

❓ Now try to fit a non-rubish sentence in this file.

💡 **HINT** You might need to change the padding depending on your sentence length.

## Gaining root access
In this section we will see how to gain root privileges by creating a new user in the `/etc/passwd` file.

‼️ **WARNING** To prevent you from breaking your VM we will first try the exploit on the file `/var/passwd` first.

### Create a new user
Let's examine what the `/etc/passwd` file looks like :

```console
$ head /etc/passwd
root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
bin:x:2:2:bin:/bin:/usr/sbin/nologin
sys:x:3:3:sys:/dev:/usr/sbin/nologin
sync:x:4:65534:sync:/bin:/bin/sync
games:x:5:60:games:/usr/games:/usr/sbin/nologin
man:x:6:12:man:/var/cache/man:/usr/sbin/nologin
lp:x:7:7:lp:/var/spool/lpd:/usr/sbin/nologin
mail:x:8:8:mail:/var/mail:/usr/sbin/nologin
news:x:9:9:news:/var/spool/news:/usr/sbin/nologin
$
```
❓ Find by yourself what is the format of this file. What information do you think can be usefull to gain root privileges?

❓ Write down (on paper or anywhere else) what you would need to write to create a new user with root privileges that spawn a shell upon login.

💡 **HINT** The *x* field means that the password are stored in the `/etc/shadow` file. We can however put an encrypted password. With perl you can generate a encrypted password with the following command.

```console
$ perl -e 'print crypt("password", "AA") . "\n"' # "AA" is the salt value, don't worry about it too much
AA6tQYSfGxd/A
$
```

Your string should look like something like this :
```
hackerman:AA6tQYSfGxd/A:0:0:me:/root:/bin/bash"
```

❗At this point the string does not end with the correct sequence has it would write to `/bin/bash` instead of `/etc/passwd`. We can however use a clever bypass by using symbolic file link. We can create any file ending with `/etc/passwd` (eg: `/var/etc/passwd`, `/tmp/etc/passwd`) and link it to `/bin/bash`.

```console
$ mkdir /tmp/var  
$ ln -s /bin/bash /tmp/var/passwd
$ ls -l /tmp/var/passwd
lrwxrwxrwx 1 kali kali 9 Jul 21 11:29 /tmp/var/passwd -> /bin/bash
$
```
❗NOTE : When testing your exploit on `/etc/passwd` you just need to replace every occurence of  `/var/passwd` by  `/etc/passwd`.
```console
$ mkdir /tmp/etc  
$ ln -s /bin/bash /tmp/etc/passwd
$ ls -l /tmp/etc/passwd
lrwxrwxrwx 1 kali kali 9 Jul 21 11:29 /tmp/etc/passwd -> /bin/bash
$
```

Our string now looks like this :
```
hackerman:AA6tQYSfGxd/A:0:0:me:/root:/tmp/etc/passwd"
```

We just need to add some padding bytes so that the string from the beginning till */tmp* has the length you computed previously.

❓ What field do you think we can use as padding ?

💡 **HINT** You can use perl or python to generate a string and check what length it has by using the following piped command 
```console
$ perl -e 'print "something"' | wc -c
9
$
```

Once you think you padded your string correctly you can try the exploit on the `/var/passwd` file.

❓ Can you append the correct user entry to the `/var/passwd` file?

If everything works fine you can try it on the  `/etc/passwd` file. (Remember to create the correct symbolic link as explained previously)

❗ **NOTE** :The program will most likely exit in a dirty fashion like **Aborted**. Don't worry about it too much.

❓ Can you log in your new user account ? What privileges do you have ?

## BONUS

One thing that could go wrong is that the buffer holding the datafile variable (in this case `/var/notes`) is not long enough to fit an interesting file name.

❓ Can you think of how to bypass this issue?

💡 **HINT** You might need the natural logarithm...

